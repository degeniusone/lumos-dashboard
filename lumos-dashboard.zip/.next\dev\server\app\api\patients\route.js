var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/patients/route.js")
R.c("server/chunks/4625f_next_2d119c3f._.js")
R.c("server/chunks/[root-of-the-server]__8bf42b1d._.js")
R.c("server/chunks/80b94_chatwoot_crm__next-internal_server_app_api_patients_route_actions_82f61c8d.js")
R.m("[project]/Documents/chatwoot_crm/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Documents/chatwoot_crm/src/app/api/patients/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/Documents/chatwoot_crm/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Documents/chatwoot_crm/src/app/api/patients/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
