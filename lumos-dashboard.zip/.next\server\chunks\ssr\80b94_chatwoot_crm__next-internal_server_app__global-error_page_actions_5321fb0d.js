module.exports=[48514,(a,b,c)=>{}];

//# sourceMappingURL=80b94_chatwoot_crm__next-internal_server_app__global-error_page_actions_5321fb0d.js.map