(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_deb3580d._.js",
  "static/chunks/4625f_next_dist_compiled_react-dom_a31735b1._.js",
  "static/chunks/4625f_next_dist_compiled_react-server-dom-turbopack_4f7d395a._.js",
  "static/chunks/4625f_next_dist_compiled_next-devtools_index_cd50828d.js",
  "static/chunks/4625f_next_dist_compiled_1c5d3894._.js",
  "static/chunks/4625f_next_dist_client_66d694fe._.js",
  "static/chunks/4625f_next_dist_3fc54055._.js",
  "static/chunks/4625f_@swc_helpers_cjs_076bb8eb._.js"
],
    source: "entry"
});
