module.exports=[78865,(e,o,d)=>{}];

//# sourceMappingURL=80b94_chatwoot_crm__next-internal_server_app_api_patients_route_actions_82f61c8d.js.map