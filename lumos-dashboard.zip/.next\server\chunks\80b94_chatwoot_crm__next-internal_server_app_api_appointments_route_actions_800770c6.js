module.exports=[22658,(e,o,d)=>{}];

//# sourceMappingURL=80b94_chatwoot_crm__next-internal_server_app_api_appointments_route_actions_800770c6.js.map