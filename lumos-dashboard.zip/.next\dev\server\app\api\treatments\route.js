var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/treatments/route.js")
R.c("server/chunks/4625f_next_83ab5aab._.js")
R.c("server/chunks/[root-of-the-server]__05ed2e48._.js")
R.c("server/chunks/80b94_chatwoot_crm__next-internal_server_app_api_treatments_route_actions_fc0afc0c.js")
R.m("[project]/Documents/chatwoot_crm/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Documents/chatwoot_crm/src/app/api/treatments/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/Documents/chatwoot_crm/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Documents/chatwoot_crm/src/app/api/treatments/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
