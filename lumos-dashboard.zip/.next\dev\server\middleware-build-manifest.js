globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/4625f_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_deb3580d._.js",
    "static/chunks/4625f_next_dist_compiled_react-dom_a31735b1._.js",
    "static/chunks/4625f_next_dist_compiled_react-server-dom-turbopack_4f7d395a._.js",
    "static/chunks/4625f_next_dist_compiled_next-devtools_index_cd50828d.js",
    "static/chunks/4625f_next_dist_compiled_1c5d3894._.js",
    "static/chunks/4625f_next_dist_client_66d694fe._.js",
    "static/chunks/4625f_next_dist_3fc54055._.js",
    "static/chunks/4625f_@swc_helpers_cjs_076bb8eb._.js",
    "static/chunks/Documents_chatwoot_crm_a0ff3932._.js",
    "static/chunks/turbopack-Documents_chatwoot_crm_e1a83f44._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];