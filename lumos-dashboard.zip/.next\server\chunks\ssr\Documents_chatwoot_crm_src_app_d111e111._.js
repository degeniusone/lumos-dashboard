module.exports=[47569,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},9575,a=>{"use strict";let b={src:a.i(47569).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=Documents_chatwoot_crm_src_app_d111e111._.js.map