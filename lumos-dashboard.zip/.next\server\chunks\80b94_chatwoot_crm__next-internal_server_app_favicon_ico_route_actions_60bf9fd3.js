module.exports=[30694,(e,o,d)=>{}];

//# sourceMappingURL=80b94_chatwoot_crm__next-internal_server_app_favicon_ico_route_actions_60bf9fd3.js.map