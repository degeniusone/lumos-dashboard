var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/treatments/route.js")
R.c("server/chunks/[root-of-the-server]__833bf9b8._.js")
R.c("server/chunks/[root-of-the-server]__deace006._.js")
R.c("server/chunks/80b94_chatwoot_crm__next-internal_server_app_api_treatments_route_actions_fc0afc0c.js")
R.m(38880)
module.exports=R.m(38880).exports
