module.exports=[90769,(a,b,c)=>{}];

//# sourceMappingURL=80b94_chatwoot_crm__next-internal_server_app__not-found_page_actions_2b8eccff.js.map