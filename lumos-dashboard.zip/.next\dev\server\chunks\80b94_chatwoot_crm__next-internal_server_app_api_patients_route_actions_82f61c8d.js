module.exports = [
"[project]/Documents/chatwoot_crm/.next-internal/server/app/api/patients/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=80b94_chatwoot_crm__next-internal_server_app_api_patients_route_actions_82f61c8d.js.map