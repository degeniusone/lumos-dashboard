module.exports = [
"[project]/Documents/chatwoot_crm/.next-internal/server/app/api/treatments/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=80b94_chatwoot_crm__next-internal_server_app_api_treatments_route_actions_fc0afc0c.js.map