var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/patients/route.js")
R.c("server/chunks/[root-of-the-server]__6381ccc2._.js")
R.c("server/chunks/[root-of-the-server]__deace006._.js")
R.c("server/chunks/80b94_chatwoot_crm__next-internal_server_app_api_patients_route_actions_82f61c8d.js")
R.m(43094)
module.exports=R.m(43094).exports
