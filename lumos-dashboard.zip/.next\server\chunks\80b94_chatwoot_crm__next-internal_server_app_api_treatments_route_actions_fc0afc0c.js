module.exports=[16192,(e,o,d)=>{}];

//# sourceMappingURL=80b94_chatwoot_crm__next-internal_server_app_api_treatments_route_actions_fc0afc0c.js.map