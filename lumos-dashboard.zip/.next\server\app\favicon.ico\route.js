var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__8dbe5856._.js")
R.c("server/chunks/[root-of-the-server]__deace006._.js")
R.c("server/chunks/4625f_next_dist_esm_build_templates_app-route_18d287a2.js")
R.c("server/chunks/80b94_chatwoot_crm__next-internal_server_app_favicon_ico_route_actions_60bf9fd3.js")
R.m(95827)
module.exports=R.m(95827).exports
