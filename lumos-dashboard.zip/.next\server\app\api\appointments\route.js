var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/appointments/route.js")
R.c("server/chunks/[root-of-the-server]__fa0b784a._.js")
R.c("server/chunks/[root-of-the-server]__deace006._.js")
R.c("server/chunks/80b94_chatwoot_crm__next-internal_server_app_api_appointments_route_actions_800770c6.js")
R.m(4751)
module.exports=R.m(4751).exports
