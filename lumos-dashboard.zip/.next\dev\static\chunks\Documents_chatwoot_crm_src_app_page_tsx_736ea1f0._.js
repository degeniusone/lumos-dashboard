(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Documents_chatwoot_crm_src_43abb281._.js",
  "static/chunks/4625f_tailwind-merge_dist_bundle-mjs_mjs_314fd467._.js",
  "static/chunks/4625f_date-fns_e1d12e82._.js",
  "static/chunks/4625f_react-day-picker_dist_esm_26b2cf93._.js",
  "static/chunks/4625f_recharts_es6_util_790cbc69._.js",
  "static/chunks/4625f_recharts_es6_state_543ce7b8._.js",
  "static/chunks/4625f_recharts_es6_component_49f598bb._.js",
  "static/chunks/4625f_recharts_es6_cartesian_3a1ea0b7._.js",
  "static/chunks/4625f_recharts_es6_44ef2deb._.js",
  "static/chunks/4625f_5517f1af._.js",
  "static/chunks/4625f_react-day-picker_src_style_7400c1ff.css"
],
    source: "dynamic"
});
